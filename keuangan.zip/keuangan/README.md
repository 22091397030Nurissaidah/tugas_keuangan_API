# Pencatatan Keuangan Harian
Aplikasi pencatatan keuangan harian ini memiliki tampilan yang sederhana dan fitur yang mampu berfungsi dengan baik.

To access. Example http://localhost/keuangan

## Tampilan Aplikasi
![ss](img/ss1.png)
![ss](img/ss2.png)
![ss](img/ss3.png)
![ss](img/ss4.png)
![ss](img/ss5.png)

## Admin Account
|  Username | Password |
|:---------:|---------:|
|  admin    |  admin   |
|  andi     |  andi    |

## Sistem Requirement
- Database MySQL
- XAMPP / PHP 5.6
- Server : XAMPP
